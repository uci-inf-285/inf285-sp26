let courseName = 'in4matx 285';
console.log(courseName);

//TODO: use toUpperCase to print the course name in all caps
//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/toUpperCase

//TODO: use substring to extract just the course number (285) from the course name, at which point isFinite will be true
//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/substring
let courseNumber = courseName;
console.log(courseNumber);
console.log(isFinite(courseNumber));