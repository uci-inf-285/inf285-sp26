//TODO: Create a variable named "fish" and give it the value 1
console.log(/*your variable*/ + ' fish');

//TODO: Add 1 to fish
console.log(/*your variable*/ + ' fish');

//TODO: Now, make fish "red"
console.log(/*your variable*/ + ' fish');

//TODO: Finally, make fish "blue"
console.log(/*your variable*/ + ' fish');