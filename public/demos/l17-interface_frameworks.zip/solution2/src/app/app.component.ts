import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { DieComponent } from './die/die.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, DieComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  die1:number = 0;
  die2:number = 0;

  rollDice() {
    this.die1 = Math.floor(Math.random()*6) + 1;
    this.die2 = Math.floor(Math.random()*6) + 1;
  }
}
