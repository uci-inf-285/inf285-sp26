

function turnLeft() {
    let wheel = document.getElementById('steering_wheel');
    wheel.classList.remove(...wheel.classList);
    wheel.classList.add('left');
}

function turnRight() {
    let wheel = document.getElementById('steering_wheel');
    wheel.classList.remove(...wheel.classList);
    wheel.classList.add('right');
}

function slowDown() {
    let slowText = document.getElementById('slowText');
    slowText.classList.remove(...slowText.classList);
    slowText.classList.add('slowDown');
}