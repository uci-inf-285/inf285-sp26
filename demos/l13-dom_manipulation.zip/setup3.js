function call() {
    let colorSelector = document.getElementById('colors');
    let toggle = document.getElementById('toggle');

    //TODO: create an event listener to listen for change events on the color selector
    //When the color changes, update the toggle's color and text to be the selected color
    //Use colorSelector.selectedOptions to determine what was selected
    //colorSelector.selectedOptions is an array. We'll discuss what the [0] means next time!
    //https://developer.mozilla.org/en-US/docs/Web/API/HTMLSelectElement/selectedOptions
    
}