let groceryItems = [
    {'name':'Apple', 'price': 1.25, 'numberToPurchase': 6},
    {'name':'Orange', 'price': 0.99, 'numberToPurchase': 12},
    {'name':'Bread', 'price': 4.53, 'numberToPurchase': 1}
];

//TODO: add two cakes to our grocery list, costing $20.89 each

let totalCost = 0;

//TODO: calculate the total amount that will be spent on groceries

console.log('Total cost: ' + totalCost);