let shoppingListArray = [];

function call() {
    //TODO: Add 2 cakes at $20.89 to the shopping list as a default entry
    let cakes = {'name': 'cake', 'cost': 20.89, 'quantity': 2};
    addToList(cakes);
}

function addToList(item) {
    //TODO: Rather than appending each item, add it to the shopping list array
    shoppingListArray.push(item);
    let newListItem = document.createElement('li');
    //TODO: Display the price and quantity alongside the item name
    newListItem.innerHTML = item['name'] + "(" + item['quantity'] + ") : $" + item['cost'] + " each";
    let shoppingList = document.getElementById('shoppingList');
    shoppingList.appendChild(newListItem);
    let totalCost = 0;
    //TODO: Calculate the total cost of the shopping list by adding up the cost of each item in the array
    for(let item of shoppingListArray) {
        totalCost = totalCost + item['cost'] * item['quantity'];
    }
    let totalCostEl = document.getElementById('totalCost');
    totalCostEl.innerHTML = '$' + totalCost;
}

function addItem() {
    let shoppingItem = document.getElementById('newItem');
    let itemCost = document.getElementById('itemCost');
    let itemQuantity = document.getElementById('itemQuantity');
    if(shoppingItem.value && itemCost.value && itemQuantity.value) {
        //TODO: Create an associative array for each item with name, quantity, and price
        let newShoppingItem = {'name':shoppingItem.value, 'cost': itemCost.value, 'quantity': itemQuantity.value};
        addToList(newShoppingItem);
        shoppingItem.value = '';
        itemCost.value = '';
        itemQuantity.value = '';
    }
}