//TODO: Create a variable named "fish" and give it the value 1
let fish = 1;
console.log(fish + ' fish');

//TODO: Add 1 to fish
fish = fish + 1;
console.log(fish + ' fish');

//TODO: Now, make fish "red"
fish = 'red';
console.log(fish + ' fish');

//TODO: Finally, make fish "blue"
fish = 'blue';
console.log(fish + ' fish');