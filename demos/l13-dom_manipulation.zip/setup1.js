function call() {
    //TODO: Give the page a new title and make it arial

    //TODO: Update the "not blue" tag with HTML, containing an em tag and make it green
    
}