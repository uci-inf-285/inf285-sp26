let groceryItems = [
    {'name':'Apple', 'price': 1.25, 'numberToPurchase': 6},
    {'name':'Orange', 'price': 0.99, 'numberToPurchase': 12},
    {'name':'Bread', 'price': 4.53, 'numberToPurchase': 1}
];

groceryItems.push({'name':'Cake', 'price':20.89, 'numberToPurchase': 2});

let totalCost = 0;

for(let groceryItem of groceryItems) {
    let costOnItem = groceryItem.price * groceryItem.numberToPurchase;
    console.log('Spending ' + costOnItem + ' on ' + groceryItem.name);
    totalCost = totalCost + costOnItem;
}

console.log('Total cost: ' + totalCost);