function call() {

}

function addItem() {
    //TODO: Add a new list item (<li>) to the shopping list with the value entered in the text box
    //TODO: Clear the text box after entry
    //TODO: Prevent entering empty items
    let shoppingItem = document.getElementById('newItem');
    let shoppingList = document.getElementById('shoppingList');
    if(shoppingItem.value) {
        let newListItem = document.createElement('li');
        newListItem.innerHTML = shoppingItem.value;
        shoppingList.appendChild(newListItem);
        shoppingItem.value = '';
    }
}