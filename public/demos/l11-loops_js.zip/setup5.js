function toCelsius(fahrenheit) {
    return (5/9) * (fahrenheit - 32);
}

// TODO: Write another function, toKelvin, which takes in two arguments.
// First argument is the temperature to convert.
// Second argument the unit of the temperature as a string, either 'celsius' or 'fahrenheit'.
// Return undefined if the some other unit is passed.
// For reference, Kelvin temperatures are Celsius temperatures +273.15. https://en.wikipedia.org/wiki/Kelvin
// Then, convert 32F to Kelvin, and 25C to Kelvin, and 99 Red Balloons to Kelvin.