function call() {
    //TODO: Give the page a new title and make it arial
    let titleTag = document.getElementById('title');
    titleTag.textContent = 'This is a new title!';
    titleTag.classList.add('arial');

    //TODO: Update the "not blue" tag with HTML, containing an em tag and make it green
    let notBluePara = document.getElementById('notblue');
    notBluePara.innerHTML = 'And <em>this</em> is new HTML.';
    notBluePara.style.color = 'green'
}