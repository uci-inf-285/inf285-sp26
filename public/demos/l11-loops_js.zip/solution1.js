//TODO: print out squares, 1*1 (1) to 10*10 (100), in order.
for(let i=1;i<=10;i=i+1) {
    console.log(i + ' squared is ' + i*i);
}